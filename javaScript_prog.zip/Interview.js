
 let array = [1,2,3,4,4,5,6,7,8,8,1,4,5];

let array1 = [];
for(let value of array){
    if(array1.indexOf(value)==-1){
        array1.push(value)
    }
}
console.log(array1);
console.log(2 + "-2" + "2")