//forEach():
let students=["abc","def","gjh","addg"];
//students.push("wett");
//students.pop();
// students.unshift("jkj");
// students.shift();
//students[1]="sdeufh";
//console.log(students);

// let std1=[];
// students.forEach(func=(element)=>{
//     std1.push(element);
    
// });
// console.log(std1);



// let array=["osman","sripriya","sravs","sandeep"];
// array.forEach(Greeting);
// function Greeting(item,index){
//     array[index]="Hello"+' '+ item;
// }
// console.log(array);
// //Greeting();


// //Slice();
// let a=["orange","apple","banana","Mango","watermelon"];
// let b=a.slice(2,4);
// console.log(b);
// //console.log(a.slice(2,4));


let arr=[1,24,3,55,44,33,20];
//let arr1=arr.sort((a,b)=>a-b);
//console.log(arr1);
console.log(arr.slice(2,3));


