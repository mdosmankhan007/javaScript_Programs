// let m=["@", "@", "@", "@"];
// for(let i in m){
// if(m[i]==="@"){

//     console.log("true");
// }
// else{
//     console.log("false");
// }
// }
// console.log("true");


//////////////////////////////////////////////

// let aa=["abc", "abc", "abc", "abc"];
// for(let i in aa){
// if(aa[i]==="abc"){
//     // console.log("true");
// }
// else{
//     console.log("false");
// }
// }
// console.log("true");

///////////////////////////////////////////////


// let a=["&&", "&", "&&&", "&&&&"];
// for(let i in a){
//     if((a[i]===0)==="&"){
//         console.log("true");
//     }
//     else{
//         console.log("false");
//     }
//     }



let a=["SS", "SS", "SS", "Ss"];

for(let i in a){
    if((a[i]%2===0)==="SS"){
        console.log("true");
    }
    else{
        console.log("false");
    }
    }
