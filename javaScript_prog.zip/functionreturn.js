function sum(a,b,c){
    let d=a+b+c;
    return d;

}
let returnVal=sum(1,2,3);
console.log(returnVal);


const firstName = "wes";
function sayHiTo (firstName) {
  return `Hello ${firstName}`;
}
const greeting = sayHiTo("Wes");
console.log(greeting);