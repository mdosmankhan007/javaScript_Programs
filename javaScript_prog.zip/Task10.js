let myColor = ["Red", "Green", "White", "Black"]
 let string = myColor.toString();
 let str= myColor.join('')
console.log(string);
console.log(str);
console.log(myColor);
console.log(myColor.join('+'));

console.log("2"<"12");
console.log(2+2+"2"+2+2);
console.log(2-2-"2"-3+3);