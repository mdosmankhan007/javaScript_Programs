/*We use the async keyword with a function to represent that the function is an asynchronous function. 
The async function returns a promise.
The syntax of async function is:

async function name(parameter1, parameter2, ...paramaterN) {
    // statements
}*/

